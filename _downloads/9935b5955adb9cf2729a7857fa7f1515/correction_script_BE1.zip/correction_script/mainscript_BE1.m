%-----les commentaires entourées de - sont des remarques des correcteurs,--
% -----non necessaire dans un code -------



clear all;  
%-----Commande pour retirer toutes les variables du workspace----
%--- permet d'éviter des erreurs de type et de tailles ---

close all; %---fermer automatiquement toutes les figures ouvertes ---

clc; %--- Effacer les messages de la console ---


% Partie 1: Estimation de la moyenne:
%% Question 1: Tracer deux réalisations de l'estimateur d'indice n pour n de 10 à 200 par pas de 10.
disp('---Partie 1: Estimation de la moyenne---')

% Paramètres
n_values = 10:10:200;  % Nombre d'observations variant de 10 à 200 par pas de 10
num_realizations = 2;  % Deux réalisations
save_fig = true;       % Sauvegarder les figures (optional)

% Initialisation
m_n = zeros(length(n_values), num_realizations); 

% Générer des échantillons aléatoires et calculer l'estimateur
for i = 1:length(n_values)
    n = n_values(i);  % Taille actuelle de l'échantillon
    X = randn(n, num_realizations);  % Générer n échantillons pour chaque réalisation
    m_n(i, :) = sum(X, 1)/n; 
end

% Tracé des réalisations
figure;
hold on;
plot(n_values, m_n, '-o', 'LineWidth', 1.5, 'MarkerSize', 5); 
yline(0, '--k', 'LineWidth', 1.5);  % Ligne de référence pour la moyenne théorique

% Labels et titre
xlabel('n', 'FontSize', 15);
ylabel('Estimateur $\hat{m}_n$', 'Interpreter', 'latex', 'FontSize', 15);
title('\''Evolution de l''estimateur de la moyenne', 'Interpreter', 'latex','FontSize', 15);

% Légende
legend('Réalisation 1', 'Réalisation 2', 'Moyenne Théorique (0)', 'Location', 'best', 'FontSize', 15);

% Sauvegarde de la figure
if save_fig
    saveas(gcf, 'estimateur_moyenne.png');
end
hold off;



%% Question 2: Tracer la moyenne des estimateurs pour diverses valeurs de n calculées avec K observations.
% Paramètres
K = 500; % Nombre de réalisations pour estimer la moyenne et l'écart type

% Initialisation des matrices de résultats
moy_empirique_normal = zeros(length(n_values), K);
moy_empirique_cauchy = zeros(length(n_values),K);


% Boucle sur les différentes valeurs de n
for i = 1:length(n_values)
    n = n_values(i); % Nombre d'observations

    % Distribution Normale 
    X_normal = randn(n,K);  % Matrice nxK avec K réalisations de taille n
    moy_empirique_normal(i,:) = sum(X_normal, 1)/n; % Moyenne sur chaque ligne (réalisation)

    % Distribution de Cauchy --- On ne modifie que la génération---
    X_cauchy = tan(pi * (rand(n, K) - 0.5)); 
    moy_empirique_cauchy(i,:) = sum(X_cauchy, 1)/n;  
end

moy_normal=mean(moy_empirique_normal,2);
ecart_normal = std(moy_empirique_normal,0,2); %--- lire la documentation attentivement pour des écarts-type suivant certaines dimensions---

moy_cauchy=mean(moy_empirique_cauchy,2);
ecart_cauchy = std(moy_empirique_cauchy,0,2); 

% Tracé pour la distribution Normale
figure;
hold on;
errorbar(n_values, moy_normal, ecart_normal, 'o-', 'LineWidth', 1.5, 'MarkerSize', 5);
plot(n_values, zeros(size(n_values)), '--k', 'LineWidth', 1.2); % Moyenne théorique (0)
plot(n_values, 1 ./ sqrt(n_values), '--r', 'LineWidth', 1.2); % Écart type théorique (1/sqrt(n))
plot(n_values, -1 ./ sqrt(n_values), '--r', 'LineWidth', 1.2);
%---Alternativement, sans errorbar --- plot(n_values,moy_normal);plot(n_values,moy_normal+ecart_normal);plot(n_values,moy_normal-ecart_normal);
xlabel('Nombre d''observations n', 'FontSize',15);
ylabel('Estimateur $\hat{m}_n$', 'Interpreter', 'latex');
title('Moyenne estimée et écart type - Distribution Normale', 'FontSize', 12);
legend('Simulation', 'Moyenne th\''eorique', '$\pm 1/\sqrt{n}$', 'Interpreter', 'latex', 'Location', 'best','Fontsize', 15);
ylim([-0.5, 0.5]);

% Sauvegarde
if save_fig
    fig=gcf;
    saveas(fig, 'moyenne_estimee_normale.png');
end
hold off;

% --- Tracé pour la distribution de Cauchy ---
figure;
errorbar(n_values, moy_cauchy, ecart_cauchy, 'o-', 'LineWidth', 1.5, 'MarkerSize', 5);
hold on;
yline(0, '--k', 'LineWidth', 1.5);  % Ligne de référence pour la localisation
xlabel('Nombre d''observations n');
ylabel('Estimateur $\hat{m}_n$', 'Interpreter', 'latex', 'FontSize',15);
title('Moyenne estimée et écart type - Distribution de Cauchy', 'FontSize', 12);
legend('Simulation','médiane' ,'Location', 'best', 'Fontsize',15);
ylim([-15, 15]); 
hold off;

% Sauvegarde
if save_fig
    saveas(gcf, 'moyenne_estimee_cauchy.png');
end


disp('-')
disp('La moyenne empirique de lois normales converge vers l''espérance, ce qui illustre la loi des grands nombres')
disp('En revanche, pour la loi de Cauchy, il n''y a pas de convergence, puisque cette loi n''a pas d''espérance')
disp('-')
%% Partie 2: Estimation de l'amplitude d'un signal
disp('---Partie 2: Estimation de l''amplitude d''un signal ---')
disp('-')
disp('La vraisemblance du signal reçu est')
disp('L(y1,...yn)=produit(1/sqrt(2 pi sigma2)e^(-(yi-theta * si)^2/(2*sigma2))')
disp('Donc la dérivée de la log-vraisemblance est')
disp('partial_theta log(L)=sum(-S''Y+theta*S''S)/sigma2')
disp('Qui s''annule en theta=S''Y/(S''S)')
disp('-')


% Test de la fonction `generer`
theta = 4;
n = 100;
s = log(1:n)';  % Génération du signal s_i = log(i)
sigma2 = 1;
K = 500;


% Générer les réalisations du signal y
Y = generer(theta, s, sigma2, K);
figure;
plot(1:n, Y(:,1), 'b', 'LineWidth', 1.5); % Une réalisation du signal y
hold on;
plot(1:n, mean(Y, 2), 'r', 'LineWidth', 2); % Moyenne des K réalisations
xlabel('Indice', 'FontSize',15);
ylabel('Valeur du Signal','FontSize',15);
title('Réalisation d''un signal y et moyenne des K réalisations', 'FontSize', 12);
legend('Réalisation de y', 'Moyenne des K réalisations', 'Location','best', 'FontSize', 12);
grid on;

if save_fig
    saveas(gcf, 'signal_log.png');
end
hold off;
% Appel de la fonction estimateur_mv
[theta_est, BCR] = estimateur_mv(s, Y, sigma2); %--- Le paramètre theta est inutile ici ---

% Calcul des valeurs théoriques et empiriques
moy_theta_est = mean(theta_est);
var_theta_est = var(theta_est, 1);

moy_theoretical = theta;


% Affichage des résultats
disp(['Moyenne théorique de theta_est : ', num2str(moy_theoretical)]);
disp(['Moyenne empirique de theta_est : ', num2str(moy_theta_est)]);
disp(['Borne de Cramer-Rao : ', num2str(BCR)]);
disp(['Variance empirique de theta_est : ', num2str(var_theta_est)]);


%% Question 5

n_estimation_MV=100:50:500';

moy_estimateur_MV=zeros(1,length(n_estimation_MV));
var_estimateur_MV=zeros(1,length(n_estimation_MV));
BCR_estimateur=zeros(1,length(n_estimation_MV));

for k =1:length(n_estimation_MV)
    s = log(1:n_estimation_MV(k))';
    Y = generer(theta, s, sigma2, K);
    [theta_est, BCR] = estimateur_mv(s, Y, sigma2);
    moy_estimateur_MV(k)=mean(theta_est);
    var_estimateur_MV(k)=var(theta_est);
    BCR_estimateur(k)=BCR;
end

figure;
plot(n_estimation_MV, moy_estimateur_MV, 'b', 'LineWidth', 1.5);

yline(theta, '--k', 'LineWidth', 1.5);  % Ligne de référence pour la localisation
xlabel('Taille du signal', 'FontSize',15);
ylabel('paramètre estimée','FontSize',15);
title('estimation de l''atténuation', 'FontSize', 12);
legend('EMV', 'valeur théorique', 'Location','best', 'FontSize', 12);
grid on;
ylim([3.99, 4.01]);
if save_fig
    saveas(gcf, 'estimation_MV.png');
end


figure;
plot(n_estimation_MV, var_estimateur_MV, 'b', 'LineWidth', 1.5);
hold on;
plot(n_estimation_MV,BCR_estimateur, '--k', 'LineWidth', 1.5);  % Ligne de référence pour la localisation
xlabel('Taille du signal', 'FontSize',15);
ylabel('Variance de l''estimateur','FontSize',15);
title('Illustration de la borne de Crameur Rao', 'FontSize', 12);
legend('estimation de la variance', 'BCR', 'Location','best', 'FontSize', 12);
grid on;
hold off;
if save_fig
    saveas(gcf, 'BCR.png');
end

disp('-');
disp('La variance empirique suis de près la borne,signe que l''estimateur est sans doute efficace');
disp('Néanmoins, la courbe empirique passe parfois sous la borne, ce qui peut sembler étonnant');
disp('Cette position est du au fait que nous traçons qu''une estimation de la variance et non la variance elle-meme');
disp('-');
disp('---Fin du BE1---');
