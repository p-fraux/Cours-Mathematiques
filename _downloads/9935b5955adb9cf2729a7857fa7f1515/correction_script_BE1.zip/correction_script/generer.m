function Y = generer(theta, signal, sigma2, K)
    % Inputs:
    % theta   : paramètre θ modélisant l'atténuation  
    % signal  : vecteur des n échantillons du signal supposé connu 
    % sigma2  : variance σ2 du bruit additif supposée connue 
    % K       : nombre de réalisations du vecteur des observations
    
    % Output:
    % Y       : une matrice Y de taille (n × K), chaque colonne étant une
    %           réalisation du signal reçu avec bruit.


    % Déterminer la longueur du signal
    n = length(signal);


    % Générer la matrice de bruit B de taille (n × K)
    B = sqrt(sigma2) * randn(n, K);
    %-------------- alternative : B= normrnd(0,sqrt(sigma2),n, K); ----------      

    % Générer la matrice Y de taille (n × K)
    Y = theta * repmat(signal, 1, K) + B;
end
