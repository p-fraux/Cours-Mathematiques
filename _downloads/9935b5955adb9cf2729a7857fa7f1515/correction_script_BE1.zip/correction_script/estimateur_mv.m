function [theta_est, BRC] = estimateur_mv(signal, Y, sigma2)
    % Function pour estimer theta et calculer la borne de Cramer-Rao
    % Inputs:
    % signal  : vecteur des n échantillons du signal supposé connu
    % Y       : matrice des observations de taille (n × K)
    % sigma2  : variance du bruit additif
    %
    % Outputs:
    % theta_est : vecteur contenant les K estimations de θ
    % BRC       : borne de Cramer-Rao pour θ


    % Initialiser le vecteur des estimations
    theta_est = (signal' * Y) / (signal' * signal);

    % Calcul de la borne de Cramer-Rao
    BRC = sigma2 / (signal' * signal);
end



