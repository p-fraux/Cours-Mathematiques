function piTheo = pi_theorique(signal,theta1,sigma2,alpha)
%Calcule la puissance théorique pour le test de Neymann-Pearson de la
%presence d'un signal dans un modele de signal attenué bruité à bruit
%gaussien 
% Inputs:
    % signal  : vecteur des n échantillons du signal supposé connu
    % theta1  : facteur d'attenuation du bruit
    % sigma2  : variance du bruit additif
    % alpha   : niveau voulu du test, peut etre un vecteur 
    %
% Outputs:
    % piTheo  : puissance théorique du test

piTheo=1-normcdf(norminv(1-alpha)-theta1*sqrt(signal'*signal/sigma2));
end 