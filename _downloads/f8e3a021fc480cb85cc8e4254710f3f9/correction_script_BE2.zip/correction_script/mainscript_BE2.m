%-----les commentaires entourées de - sont des remarques des correcteurs,--
% -----non necessaire dans un code -------
clear;  
close all;
clc;

save_fig = true;       % Sauvegarder les figures (optional)

%% Partie 1
disp('---Partie 1 : Test et detection de signal---')
disp('-')
disp('Les hypothèses étant simple et parametrique, nous pouvons utiliser le test de Neymann-Pearson')
disp('On rejetera donc H0 si L1/L0>C')
disp('Ce qui équivaut à produit(exp(-(yi-theta*si)**2/(2*sigma2)+yi**2/(2*sigma2)>C')
disp('Ou encore sum(theta yi*si-si**2)/(2*sigma2>C')
disp('ou encore, comme theta>0, à sum( yi*si)>C')
disp('qui est le résultat annoncé')

%Initialisation des variables
theta1=1;
n=20;
sigma2=1:3;
alpha=0.01:0.01:0.99;
K=500;
signal=sin(2*pi*0.1*(1:n))';


%Calcul et tracé des courbes
hold on
Legend_complete=cell(size(sigma2));
i=0; % --- Indice pour l'écriture automatique de legende
for variance=sigma2
    i=i+1;
    plot(alpha,pi_theorique(signal,theta1,variance,alpha));
    Legend_complete(i)=cellstr(strcat('\sigma2=',num2str(variance)));
end
xlabel('niveau du test $\alpha$','Interpreter', 'latex',  'FontSize', 15);
ylabel('puissance du test $1-\beta$', 'Interpreter', 'latex', 'FontSize', 15);
legend(Legend_complete);
title('Courbe ROC théorique')
if save_fig  % Sauvegarde de la figure
    saveas(gcf, 'courbe_ROC_estimee.png');
end
hold off

figure();
scolor=jet(length(sigma2));
hold on
Legend_complete=cell(size(sigma2));

for i=1:length(sigma2)
    plot(alpha,pi_theorique(signal,theta1,sigma2(i),alpha),'color',scolor(i,:));
    stairs(alpha,pi_estimee(signal,theta1,sigma2(i),K,alpha),'color',scolor(i,:));
    Legend_complete(i)=cellstr(strcat('\sigma2=',num2str(sigma2(i))));

end

xlabel('niveau du test $\alpha$','Interpreter', 'latex',  'FontSize', 15);
ylabel('puissance estimee du test $1-\beta$', 'Interpreter', 'latex', 'FontSize', 15);
legend(Legend_complete);
title('Courbe ROC empirique')
if save_fig  % Sauvegarde de la figure
    saveas(gcf, 'courbe_ROC_estimee.png');
end
hold off

disp('-');
disp('La courbe ROC est bien estimée par les fréquences empiriques !');


%% Partie 2
disp('-');
disp('---Partie 2 : Regression linéaire et problèmes régulieremnt rencontrés---');
disp('-');
load carsmall.mat;

y=MPG;
x1=Weight;
x2=Horsepower;
X=[ones(length(y),1) x1 x2];

y_hat=(X'*X)\(X'*y);
disp(y_hat)
disp('Le resultat n''est pas un nombre (NaN)');
disp('En effet, y tout comme X contiennent déja des NaN');
disp('ce qui correspond à une bonne pratique dans un tableau de donnée pour marquer une donnée manquante')
disp('et éviter à un programmeur trop rapide d''essayer d''utiliser ces valeurs');
disp('-');
disp('Pour circonvenir des données manquantes, on peut ne pas solliciter les lignes pour lesquelles n''importe laquelle des 3 variables n''a pas de données');

% Calculs de la regression
a_estimee=regress(y,X);
[meshX1, meshX2]=meshgrid(min(x1):100:max(x1),min(x2):10:max(x2));
Matrice_mesh =cat(3,ones(size(meshX1)),meshX1, meshX2 ) ;%Construction d'un tenseur où chaque hauteur est une des valeurs explicatives
y_estimee=tensorprod(Matrice_mesh,a_estimee,3,1);

% Affichages graphique des résultats
mesh(meshX1 ,meshX2,y_estimee)
hold on
scatter3(x1,x2,y)
xlabel('Poids','Interpreter', 'latex',  'FontSize', 15);
ylabel('Puissance du moteur', 'Interpreter', 'latex', 'FontSize', 15);
zlabel('Consomation', 'Interpreter', 'latex', 'FontSize', 15);
legend('Régression','données');
title('Regression : consomation fonction du poids et de la puissance')
if save_fig  % Sauvegarde de la figure
    saveas(gcf, 'Regression.png');
end
hold off



%% Choix du modèle de regression
disp('-');
disp('---Partie 3 : Regression linéaire et problèmes régulieremnt rencontrés---');
disp('-');



load hald
whichstats = {'mse','rsquare'};
s_linear=regstats(heat,ingredients,'linear',whichstats);
s_linear_interaction=regstats(heat,ingredients,'interaction',whichstats);
s_pur_quadratique=regstats(heat,ingredients,'purequadratic',whichstats);
disp('Pour l''erreur quadratique moyenne,')
disp('   le modele linéaire obtient '+string(s_linear.mse))
disp('   le modele linéaire avec interaction obtient '+string(s_linear_interaction.mse))
disp('   le modele quadratique obtient '+string(s_pur_quadratique.mse))
disp('-');
disp('Pour le coefficient de détermination R**2,')
disp('   le modele linéaire obtient '+string(s_linear.rsquare))
disp('   le modele linéaire avec interaction obtient '+string(s_linear_interaction.rsquare))
disp('   le modele quadratique obtient '+string(s_pur_quadratique.rsquare))

disp('-');
disp('Le modèle linéaire avec intéraction ayant une plus petite erreur et un meilleur coefficient, nous choississons donc ce modèle')