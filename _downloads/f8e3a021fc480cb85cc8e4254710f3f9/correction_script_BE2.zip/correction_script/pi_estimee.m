function piEst = pi_estimee(signal,theta1,sigma2,K,alpha)
%Estime la puissance pour le test de Neymann-Pearson par la fréquence
%empirique
% Inputs:
    % signal  : vecteur des n échantillons du signal supposé connu
    % theta1  : facteur d'attenuation du bruit
    % sigma2  : variance du bruit additif
    % K       : nombre de réalisation pour l'estimation de la probabilité
    % alpha   : niveau voulu du test, peut etre un vecteur
    %
% Outputs:
    % piEst : puissance estimée du test
    lambda=sqrt(sigma2*(signal'*signal))*norminv(1-alpha);
    observations=generer(theta1, signal, sigma2, K);
    results=zeros(size(alpha));

    for indice_puissance=1:length(alpha)
        Z=signal'*observations>lambda(indice_puissance);
        results(indice_puissance)=sum(Z)/K;
    end
    piEst=results;
end